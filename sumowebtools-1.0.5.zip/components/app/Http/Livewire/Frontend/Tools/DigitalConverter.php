<?php

namespace App\Http\Livewire\Frontend\Tools;

use Livewire\Component;
use App\Models\Admin\History;
use App\Classes\DigitalConverterClass;
use DateTime, File;
use GeoIp2\Database\Reader;
use GeoIp2\Exception\AddressNotFoundException;

class DigitalConverter extends Component
{

    public $from_value;
    public $convert_from = 'bit';
    public $from_name;

    public $data = [];

    public function render()
    {
        return view('livewire.frontend.tools.digital-converter');
    }

    public function onDigitalConverter(){

        $this->validate([
            'from_value'     => 'required|numeric|gt:0',
            'convert_from' => 'required'
        ]);

        $this->data = null;

        try {

            if (File::exists( app_path('Classes') ))
            {

                $output = new DigitalConverterClass();

                $this->data = $output->get_data( $this->from_value, $this->convert_from );
            
                $this->from_name = ucfirst($this->convert_from);

            } else $this->addError('error', __('Missing addons detected. Please make sure you read the documentation!'));

        } catch (\Exception $e) {

            $this->addError('error', __($e->getMessage()));
        }

        //Save History
        if ( !empty($this->data) ) {

            $history             = new History;
            $history->tool_name  = 'Digital Calculator';
            $history->client_ip  = request()->ip();

            require app_path('Classes/geoip2.phar');

            $reader = new Reader( app_path('Classes/GeoLite2-City.mmdb') );

            try {

                $record           = $reader->city( request()->ip() );

                $history->flag    = strtolower( $record->country->isoCode );
                
                $history->country = strip_tags( $record->country->name );

            } catch (AddressNotFoundException $e) {

            }

            $history->created_at = new DateTime();
            $history->save();
        }

    }

    public function onSample()
    {
        $this->from_value = 12;
    }

    public function onReset()
    {
        $this->from_value = null;
        $this->data       = null;
    }
}
