<?php

namespace App\Http\Livewire\Frontend\Tools;

use Livewire\Component;
use App\Models\Admin\History;
use DateTime, File;
use GeoIp2\Database\Reader;
use GeoIp2\Exception\AddressNotFoundException;

class CsvToJson extends Component
{

    public $csv;
    public $data;

    public function render()
    {
        return view('livewire.frontend.tools.csv-to-json');
    }

    private function csvToJson($data) {
        
          $array = array_map("str_getcsv", explode("\n", $data));

          $labels = array_shift($array);

          foreach($labels as $label)
          {
            $column_name[] = $label;
          }

          $count = count($array) - 1;

          for($j = 0; $j < $count; $j++)
          {
            $data = array_combine($column_name, $array[$j]);

            $result[$j] = $data;
          }

          return json_encode($result);
    }

    public function onCsvToJson(){

        $this->validate([
            'csv'   => 'required'
        ]);

        $this->data = null;

        try {

            if (File::exists( app_path('Classes') ))
            {
                $this->data = $this->csvToJson($this->csv);

            } else $this->addError('error', __('Missing addons detected. Please make sure you read the documentation!'));
            
        } catch (\Exception $e) {

            $this->addError('error', __($e->getMessage()));
        }

        //Save History
        if ( !empty($this->data) ) {

            $history             = new History;
            $history->tool_name  = 'CSV to JSON';
            $history->client_ip  = request()->ip();

            require app_path('Classes/geoip2.phar');

            $reader = new Reader( app_path('Classes/GeoLite2-City.mmdb') );

            try {

                $record           = $reader->city( request()->ip() );

                $history->flag    = strtolower( $record->country->isoCode );
                
                $history->country = strip_tags( $record->country->name );

            } catch (AddressNotFoundException $e) {

            }

            $history->created_at = new DateTime();
            $history->save();
        }

    }

    public function onSample()
    {
        $this->csv = 'album, year
The White Stripes, 1999
De Stijl, 2000
White Blood Cells, 2001';
        
        $this->data = null;
    }

    public function onReset()
    {
        $this->csv = '';
        $this->data = null;
    }
}

