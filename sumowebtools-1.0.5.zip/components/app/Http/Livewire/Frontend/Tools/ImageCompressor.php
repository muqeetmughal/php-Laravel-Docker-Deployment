<?php

namespace App\Http\Livewire\Frontend\Tools;

use Livewire\Component;
use App\Models\Admin\History;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use DateTime, File;
use App\Models\Admin\General;
use Image;
use Livewire\WithFileUploads;
use Illuminate\Http\Request;
use ImageOptimizer;
use GeoIp2\Database\Reader;
use GeoIp2\Exception\AddressNotFoundException;

class ImageCompressor extends Component
{

    use WithFileUploads;

    protected $listeners = ['onImageCropper'];
    public $convertType = 'localImage';
    public $remote_url;

    public function render()
    {
        return view('livewire.frontend.tools.image-compressor');
    }

    /**
     * -------------------------------------------------------------------------------
     *  Convert Type
     * -------------------------------------------------------------------------------
    **/
    public function onConvertType( $type ){
        $this->convertType = $type;
    }

    /**
     * -------------------------------------------------------------------------------
     *  Add Remote URL
     * -------------------------------------------------------------------------------
    **/
    public function onAddRemoteURL()
    {

        $this->validate([
            'remote_url' => 'required|url'
        ]);
        
        try {

            $fileName     = pathinfo($this->remote_url, PATHINFO_BASENAME);            

            $fileNameTemp = time() . '.' . pathinfo( $this->remote_url, PATHINFO_EXTENSION);

            Storage::disk('local')->put('livewire-tmp/' . $fileNameTemp, Http::get($this->remote_url) );
            
            $temp_url     = asset('components/storage/app/livewire-tmp/' . $fileNameTemp);

            $fileType     = File::mimeType( storage_path('app/livewire-tmp/') . $fileNameTemp );

            $this->dispatchBrowserEvent('onSetRemoteURL', ['url' => $temp_url, 'fileName' => $fileName, 'fileType' => $fileType ]);

        } catch (\Exception $e) {

            $this->addError('error', __($e->getMessage()));
        }
    }

    /**
     * -------------------------------------------------------------------------------
     *  Format Size Units
     * -------------------------------------------------------------------------------
    **/
    function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
    }

    /**
     * -------------------------------------------------------------------------------
     *  Image Compressor
     * -------------------------------------------------------------------------------
    **/
    public function onImageCompressor(Request $request){

        try {

            if (File::exists( app_path('Classes') ))
            {

                $files = $request->file('file');

                foreach ($files as $file) {

                    $fileName = $file->getClientOriginalName();

                    $fileType = $file->getClientOriginalExtension();

                    //
                    $file->move(storage_path('app/livewire-tmp'), $fileName);

                    $oldFileSize = File::size( storage_path('app/livewire-tmp/') . $fileName );
                    
                    //
                    $newFileName = General::first()->prefix . time() . '.' . $fileType;

                    ImageOptimizer::optimize( storage_path('app/livewire-tmp/') . $fileName, storage_path('app/livewire-tmp/') . $newFileName);

                    $newFileSize = File::size( storage_path('app/livewire-tmp/') . $newFileName );

                    $saved = round( 100 - ($newFileSize / $oldFileSize * 100) );

                    $dataFiles['url']      = asset('components/storage/app/livewire-tmp/' . $newFileName);
                    $dataFiles['filename'] = General::orderBy('id', 'DESC')->first()->prefix . time();
                    $dataFiles['type']     = $fileType;
                    $dlLink                = url('/') . '/dl.php?token=' . $this->encode( json_encode($dataFiles) );

                    $data['success']  = true;
                    $data['status']   = 'Finished';
                    $data['old_size'] = $this->formatSizeUnits($oldFileSize);
                    $data['new_size'] = $this->formatSizeUnits($newFileSize);
                    $data['saved']    = $saved . '%';
                    $data['link']     = $dlLink;

                    return $data;

                }

            } else $this->addError('error', __('Missing addons detected. Please make sure you read the documentation!'));
                    
        } catch (\Exception $e) {

            $this->addError('error', __($e->getMessage()));
        }

        //Save History
        $history             = new History;
        $history->tool_name  = 'Image Compressor';
        $history->client_ip  = request()->ip();

        require app_path('Classes/geoip2.phar');

        $reader = new Reader( app_path('Classes/GeoLite2-City.mmdb') );

        try {

            $record           = $reader->city( request()->ip() );

            $history->flag    = strtolower( $record->country->isoCode );
            
            $history->country = strip_tags( $record->country->name );

        } catch (AddressNotFoundException $e) {

        }

        $history->created_at = new DateTime();
        $history->save();

    }

    function encode($pData)
    {
        $encryption_key = 'themeluxurydotcom';

        $encryption_iv = '9999999999999999';

        $ciphering = "AES-256-CTR"; 
          
        $encryption = openssl_encrypt($pData, $ciphering, $encryption_key, 0, $encryption_iv);

        return $encryption;
    }

}
