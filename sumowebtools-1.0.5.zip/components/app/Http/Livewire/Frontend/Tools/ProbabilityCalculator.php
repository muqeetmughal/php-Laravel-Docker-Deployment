<?php

namespace App\Http\Livewire\Frontend\Tools;

use Livewire\Component;
use App\Models\Admin\History;
use DateTime, File;
use GeoIp2\Database\Reader;
use GeoIp2\Exception\AddressNotFoundException;

class ProbabilityCalculator extends Component
{

    public $outcomes;
    public $events_occured;

    public $data = [];

    public function render()
    {
        return view('livewire.frontend.tools.probability-calculator');
    }

    public function onProbabilityCalculator(){

        $this->validate([
            'outcomes'       => 'required|numeric',
            'events_occured' => 'required|numeric',
        ]);

        $this->data = null;

        try {

            if (File::exists( app_path('Classes') ))
            {

                $occurs                   = (($this->events_occured / $this->outcomes ) * 1000 ) / 1000;
                $this->data['occurs']     = number_format($occurs, 2);
                $this->data['not_occurs'] = number_format(((1 - $occurs) * 1000) / 1000, 2);

            } else $this->addError('error', __('Missing addons detected. Please make sure you read the documentation!'));

        } catch (\Exception $e) {

            $this->addError('error', __($e->getMessage()));
        }

        //Save History
        if ( !empty($this->data) ) {

            $history             = new History;
            $history->tool_name  = 'Probability Calculator';
            $history->client_ip  = request()->ip();

            require app_path('Classes/geoip2.phar');

            $reader = new Reader( app_path('Classes/GeoLite2-City.mmdb') );

            try {

                $record           = $reader->city( request()->ip() );

                $history->flag    = strtolower( $record->country->isoCode );
                
                $history->country = strip_tags( $record->country->name );

            } catch (AddressNotFoundException $e) {

            }

            $history->created_at = new DateTime();
            $history->save();
        }

    }

    public function onSample()
    {
        $this->outcomes       = 9;
        $this->events_occured = 3;
    }

    public function onReset()
    {
        $this->outcomes       = null;
        $this->events_occured = null;
    }
}
