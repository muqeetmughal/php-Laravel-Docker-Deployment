<?php

namespace App\Http\Livewire\Frontend\Tools;

use Livewire\Component;
use App\Models\Admin\History;
use Illuminate\Support\Facades\Http;
use App\Classes\IcoToPngClass;
use Livewire\WithFileUploads;
use DateTime, File;
use GeoIp2\Database\Reader;
use GeoIp2\Exception\AddressNotFoundException;
use App\Models\Admin\General;

class IcoToPng extends Component
{
    use WithFileUploads;

    protected $listeners = ['onSetRemoteURL'];
    public $convertType = 'localImage';
    public $remote_url;
    public $local_image;
    public $data = [];

    public function render()
    {
        return view('livewire.frontend.tools.ico-to-png');
    }

    public function onSetRemoteURL($value)
    {
      $this->remote_url = $value;
    }

    public function onConvertType( $type ){
        $this->convertType = $type;
    }

    public function onIcoToPng(){

        if ( $this->convertType == 'remoteURL') {
            $this->validate([
                'remote_url' => 'required|url'
            ]); 
        }
        else {
            $this->validate([
                'local_image' => 'required|mimes:ico|file|max:'. 1024 * General::first()->file_size.'',
            ]);
        }

        $this->data = null;

        try {

            if (File::exists( app_path('Classes') ))
            {

                $output = new IcoToPngClass();

                if ( $this->convertType == 'remoteURL') {
                    $temp_url = $this->remote_url;
                }
                else {
                    $temp_path = $this->local_image->store('livewire-tmp');
                    $temp_url = asset('components/storage/app/' . $temp_path);
                }
                
                if ( pathinfo( $temp_url, PATHINFO_EXTENSION) == 'ico') {

                    $this->data = $output->get_data( $temp_url );

                } else $this->addError('error', __('The image must be a file of type: ico.'));

            } else $this->addError('error', __('Missing addons detected. Please make sure you read the documentation!'));

        } catch (\Exception $e) {

            $this->addError('error', __($e->getMessage()));
        }

        //Save History
        if ( !empty($this->data) ) {

            $history             = new History;
            $history->tool_name  = 'ICO to PNG';
            $history->client_ip  = request()->ip();

            require app_path('Classes/geoip2.phar');

            $reader = new Reader( app_path('Classes/GeoLite2-City.mmdb') );

            try {

                $record           = $reader->city( request()->ip() );

                $history->flag    = strtolower( $record->country->isoCode );
                
                $history->country = strip_tags( $record->country->name );

            } catch (AddressNotFoundException $e) {

            }

            $history->created_at = new DateTime();
            $history->save();
        }
        
    }

}
