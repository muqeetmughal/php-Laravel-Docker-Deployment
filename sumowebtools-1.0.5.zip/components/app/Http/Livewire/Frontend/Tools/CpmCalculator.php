<?php

namespace App\Http\Livewire\Frontend\Tools;

use Livewire\Component;
use App\Models\Admin\History;
use DateTime, File;
use GeoIp2\Database\Reader;
use GeoIp2\Exception\AddressNotFoundException;

class CpmCalculator extends Component
{

    public $cost;
    public $cpm;
    public $impressions;

    public $data = [];

    public function render()
    {
        return view('livewire.frontend.tools.cpm-calculator');
    }

    public function onCpmCalculator(){

        $this->data = null;

        try {

            if (File::exists( app_path('Classes') ))
            {

                if ($this->cost != null && $this->cpm != null && $this->impressions == null) {

                    $this->data['cpm']            =  number_format($this->cpm);

                    $this->data['ad_impressions'] =  number_format($this->cost / $this->cpm * 1e3);

                    $this->data['amount']         =  number_format($this->cost);

                } else if( $this->cost != null && $this->impressions != null && $this->cpm == null) {

                    $this->data['cpm']            =  number_format( ((100 * ($this->cost / $this->impressions * 1e3 )) / 100 ) );

                    $this->data['ad_impressions'] =  number_format($this->impressions);

                    $this->data['amount']         =  number_format($this->cost);

                } else if($this->impressions != null && $this->cpm != null && $this->cost == null) {

                    $this->data['cpm']            =  number_format($this->cpm);

                    $this->data['ad_impressions'] =  number_format($this->impressions);

                    $this->data['amount']         =  number_format($this->cpm * ( $this->impressions / 1e3));

                }
                else $this->addError('error', __('You need to enter two of the fields using this calculator, and it will resolve the last one.'));

            } else $this->addError('error', __('Missing addons detected. Please make sure you read the documentation!'));

        } catch (\Exception $e) {

            $this->addError('error', __($e->getMessage()));
        }

        //Save History
        if ( !empty($this->data) ) {

            $history             = new History;
            $history->tool_name  = 'CPM Calculator';
            $history->client_ip  = request()->ip();

            require app_path('Classes/geoip2.phar');

            $reader = new Reader( app_path('Classes/GeoLite2-City.mmdb') );

            try {

                $record           = $reader->city( request()->ip() );

                $history->flag    = strtolower( $record->country->isoCode );
                
                $history->country = strip_tags( $record->country->name );

            } catch (AddressNotFoundException $e) {

            }

            $history->created_at = new DateTime();
            $history->save();
        }

    }

    public function onSample()
    {
        $this->cost = 100;
        $this->cpm  = 10;
    }

    public function onReset()
    {
        $this->cost        = null;
        $this->cpm         = null;
        $this->impressions = null;
        $this->data        = null;
    }
}
