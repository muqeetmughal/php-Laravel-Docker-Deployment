<?php

namespace App\Http\Livewire\Frontend\AuthPages;

use Livewire\Component;

class Page404 extends Component
{
    public function render()
    {
        return view('livewire.frontend.auth-pages.page404');
    }
}
