<div>

      <form wire:submit.prevent="onAreaConverter">

        <div>
            <!-- Session Status -->
            <x-auth-session-status class="mb-4" :status="session('status')" />
                                        
            <!-- Validation Errors -->
            <x-auth-validation-errors class="mb-4" :errors="$errors" />
        </div>

        <div class="form-group mb-3 ">
            <label class="form-label">{{ __('Value') }}</label>
            <input type="number" wire:model="from_value" class="form-control" required>
        </div>

        <div class="form-group mb-3">
            <label class="form-label">{{ __('Convert From :from to Others', ['from' => ucfirst(str_replace('_', ' ', $convert_from)) ]) }}</label>
            <select wire:model="convert_from" class="form-control">
                <option value="meter">{{ __('Square Meter') }}</option>
                <option value="kilometer">{{ __('Square Kilometer') }}</option>
                <option value="centimeter">{{ __('Square Centimeter') }}</option>
                <option value="millimeter">{{ __('Square Millimeter') }}</option>
                <option value="micrometer">{{ __('Square Micrometer') }}</option>
                <option value="hectare">{{ __('Hectare') }}</option>
                <option value="mile">{{ __('Square Mile') }}</option>
                <option value="yard">{{ __('Square Yard') }}</option>
                <option value="foot">{{ __('Square Foot') }}</option>
                <option value="inch">{{ __('Square Inch') }}</option>
                <option value="acre">{{ __('Acre') }}</option>
            </select>
        </div>

        <div class="form-group mb-3 text-center">
            <button class="btn btn-info" wire:loading.attr="disabled">
              <span>
                <div wire:loading.inline wire:target="onAreaConverter">
                  <x-loading />
                </div>
                <span wire:target="onAreaConverter">{{ __('Calculate') }}</span>
              </span>
            </button>

            <button class="btn btn-lime" wire:click.prevent="onSample" wire:loading.attr="disabled">
              <span>
                <div wire:loading.inline wire:target="onSample">
                  <x-loading />
                </div>
                <span wire:target="onSample">{{ __('Sample') }}</span>
              </span>
            </button>

            <button class="btn btn-warning" wire:click.prevent="onReset" wire:loading.attr="disabled">
              <span>
                <div wire:loading.inline wire:target="onReset">
                  <x-loading />
                </div>
                <span wire:target="onReset">{{ __('Reset') }}</span>
              </span>
            </button>
        </div>

        @if ( !empty($data) )
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <tbody>
                        @foreach ($data as $key => $value)
                            <tr>
                                <td class="font-weight-bold">{{ ucfirst(str_replace('_', ' ', $from_name)) }} {{ __('to') }} {{ ucfirst(str_replace('_', ' ', $key)) }}</td>
                                <td>{{ $value }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif

      </form>
</div>