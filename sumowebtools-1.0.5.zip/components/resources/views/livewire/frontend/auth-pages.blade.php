  <div class="page">
    <x-frontend.navbar :header="$header" :siteTitle="$siteTitle" :menus="$menus" :general="$general" />

    <main class="main">

        @if(Auth::user() && \App\Models\Admin\AuthPages::where('name', 'Verify Email')->first()->status == true && Auth::user()->email_verified_at == null)
            <div class="alert alert-important alert-warning alert-dismissible mb-0 text-center rounded-0" role="alert">
              {{ __('Your email address is not verified.') }} <a href="{{ route('verify-email') }}" class="alert-link text-decoration-underline">{{ __('Verify it here!') }}</a>
            </div>
        @endif

        @switch(true)

            @case( Route::is('login') )
                    @if ( \App\Models\Admin\AuthPages::where('name', 'Login')->first()->status == true )
                        @livewire('frontend.auth-pages.login')
                    @else
                        @include('errors.disabled', ['message' => 'Login'])
                    @endif
                @break

            @case( Route::is('admin-login') )
                    @livewire('frontend.auth-pages.login')
                @break

            @case( Route::is('register') )
                    @if ( \App\Models\Admin\AuthPages::where('name', 'Register')->first()->status == true )
                        @livewire('frontend.auth-pages.register')
                    @else
                        @include('errors.disabled', ['message' => 'Register'])
                    @endif
                @break

            @case( Route::is('forgot-password') )
                    @if ( \App\Models\Admin\AuthPages::where('name', 'Forgot Password')->first()->status == true )
                        @livewire('frontend.auth-pages.forgot-password')
                    @else
                        @include('errors.disabled', ['message' => 'Forgot Password'])
                    @endif
                @break

            @case( Route::is('password.reset') )
                    @if ( \App\Models\Admin\AuthPages::where('name', 'Reset Password')->first()->status == true )
                        @livewire('frontend.auth-pages.reset-password', [
                                  'token' => request()->token,
                                  'email' => request()->email
                                ])
                    @else
                        @include('errors.disabled', ['message' => 'Reset Password'])
                    @endif
                @break

            @case( Route::is('verify-email') )
                    @if ( \App\Models\Admin\AuthPages::where('name', 'Verify Email')->first()->status == true )
                        @livewire('frontend.auth-pages.verify-email')
                    @else
                        @include('errors.disabled', ['message' => 'Verify Email'])
                    @endif
                @break

            @case( Route::is('user-profile') )
                    @if ( \App\Models\Admin\AuthPages::where('name', 'Profile')->first()->status == true )
                        @livewire('frontend.auth-pages.profile')
                    @else
                        @include('errors.disabled', ['message' => 'Profile'])
                    @endif
                @break

            @default
                
        @endswitch
        
    </main>

    <x-frontend.footer :footer="$footer" :general="$general" :socials="$socials" />

    <!-- jQuery -->
    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>

    <!-- Theme JS -->
    <script src="{{ asset('assets/js/main.min.js') }}"></script>

    @if ( $general->lazy_loading == true )
      <script src="{{ asset('assets/js/lazysizes.min.js') }}"></script>
      <script src="{{ asset('assets/js/ls.unveilhooks.min.js') }}"></script>
    @endif

    @if ( $captcha->status == true && !empty($captcha->site_key ) && !empty($captcha->secret_key ) )
      <script src="https://www.google.com/recaptcha/api.js?render={{ $captcha->site_key }}"></script>
    @endif

    @if ( $general->back_to_top == true )
        <!-- Scroll back to top -->
        <div id="backtotop"> 
            <a href="javascript:void(0)" class="backtotop"></a> 
        </div>

        <script type="text/javascript"> 
            jQuery(document).ready(function ($) {
                $("#backtotop").hide(); 
                $(window).scroll(function () { 
                    if ($(this).scrollTop() > 500) { 
                        $('#backtotop').fadeIn(); 
                    } else { 
                        $('#backtotop').fadeOut(); 
                    } 
                });   
            });

            jQuery('.backtotop').click(function () { 
                jQuery('html, body').animate({ 
                    scrollTop: 0 
                }, 'slow'); 
            });
        </script> 
        <!-- End of Scroll back to top -->
    @endif
    
    @if (Cookie::get('cookies') == null)

      @if ( $notice->status == true )

            <div class="cookies-wrapper position-fixed {{ $notice->align }}">
                <div class="{{ $notice->background }} {{ ($notice->background != 'bg-white') ? 'text-white' : 'text-dark' }} py-3 px-2 rounded shadow">
                    <div class="card-body">
                        <div class="mb-3">
                            <img src="{{ asset('assets/img/cookie.svg') }}" alt="{{ __('Cookie') }}">
                        </div>

                        <div>
                            <span class="text-start">{!! __(GrahamCampbell\Security\Facades\Security::clean($notice->notice)) !!}</span>
                        </div>
                    </div>

                        @if ( $notice->button == true)
                            <div class="text-center">
                                <button id="acceptCookies" class="btn bg-success mb-0 text-capitalize text-white"> {{ __('Accept all cookies') }} </button>
                            </div>
                         @endif
                    </div>

                </div>
            </div>

          <script>
             (function( $ ) {
                "use strict";

                    jQuery("#acceptCookies").click(function(){
                        jQuery.ajax({
                            type : 'get',
                            url : '{{ url('/') }}/cookies/accept',
                            success: function(e) {
                                jQuery('.cookies-wrapper').remove();
                            }
                        });
                    });

            })( jQuery );
          </script>
      @endif

    @endif

    @if ( $general->dir_mode == true )
      <script>
         (function( $ ) {
            "use strict";

                jQuery(".btn-toggle-dir").click(function(){
                    jQuery.ajax({
                        type : 'get',
                        url : '{{ url('/') }}/dir/mode',
                        success: function(e) {
                            window.location.reload();
                        }
                    });
                });

        })( jQuery );
      </script>
    @endif
        
    @if ( $general->theme_mode == true )
      <script>
         (function( $ ) {
            "use strict";

                jQuery(".btn-toggle-mode").click(function(){
                    jQuery.ajax({
                        type : 'get',
                        url : '{{ url('/') }}/theme/mode',
                        success: function(e) {
                            jQuery('body').toggleClass("theme-dark");
                        }
                    });
                });

        })( jQuery );
      </script>
    @endif

    @if ( $advanced->footer_status == true && $advanced->insert_footer != null )
      {!! $advanced->insert_footer !!}
    @endif

  </div>