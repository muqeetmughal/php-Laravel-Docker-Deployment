  <div class="page">
    <x-frontend.navbar :header="$header" :siteTitle="$siteTitle" :menus="$menus" :general="$general" />

    <main class="main">

        @if(Auth::user() && \App\Models\Admin\AuthPages::where('name', 'Verify Email')->first()->status == true && Auth::user()->email_verified_at == null)
            <div class="alert alert-important alert-warning alert-dismissible mb-0 text-center rounded-0" role="alert">
              {{ __('Your email address is not verified.') }} <a href="{{ route('verify-email') }}" class="alert-link text-decoration-underline">{{ __('Verify it here!') }}</a>
            </div>
        @endif

        @if ( $general->parallax_status == true )
            <section id="parallax" class="text-white">
                <div class="position-relative overflow-hidden text-center bg-light">
                  <span class="mask" style="
                        @if ( $general->overlay_type == 'solid' )

                        background: {{ $general->solid_color }};opacity: {{ $general->opacity }};

                        @elseif( $general->overlay_type == 'gradient' )

                        background: {{ $general->gradient_first_color }};
                        background: -moz-linear-gradient( {{ $general->gradient_position }}, {{ $general->gradient_first_color }}, {{ $general->gradient_second_color }}  );
                        background: -webkit-linear-gradient( {{ $general->gradient_position }}, {{ $general->gradient_first_color }}, {{ $general->gradient_second_color }} );
                        background: linear-gradient( {{ $general->gradient_position }}, {{ $general->gradient_first_color }}, {{ $general->gradient_second_color }} );
                        opacity: {{ $general->opacity }};

                        @endif

                  "></span>

                  @if ( !empty($general->parallax_image) )
                    <div class="position-absolute start-0 top-0 w-100 parallax-image {{ ($general->lazy_loading == true) ? 'lazyload' : '' }}" data-bg="{{ $general->parallax_image }}" style="filter: blur({{ $general->blur }}px);@if ($general->lazy_loading == false) background-image:url({{ $general->parallax_image }}); @endif"></div>
                  @else
                    <div class="position-absolute start-0 top-0 w-100 parallax-image {{ ($general->lazy_loading == true) ? 'lazyload' : '' }}" data-bg="{{ $general->parallax_image }}" style="filter: blur({{ $general->blur }}px);@if ($general->lazy_loading == false) background-image:url({{ $general->parallax_image }}); @endif"></div>
                  @endif

                  <div class="container position-relative zindex-1">
                      <div class="col text-center p-lg-5 mx-auto my-5">

                          @if ( $page->ads_status == true && $advertisement->area1_status == true && $advertisement->area1 != null )
                            <x-frontend.advertisement.area1 :advertisement="$advertisement" />
                          @endif

                          <h1 class="display-5 font-weight-normal">{{ __($pageTrans->title) }}</h1>
                          <h2 class="font-weight-normal">{{ __($pageTrans->subtitle) }}</h2>

                          @if ( $page->ads_status == true && $advertisement->area2_status == true && $advertisement->area2 != null )
                            <x-frontend.advertisement.area2 :advertisement="$advertisement" />
                          @endif
                      </div>
                  </div>

                </div>
            </section>
        @endif

        <section>
            <div class="container py-4">
                <div class="row">
                    <div class="{{ ( $page->ads_status == true && ( ( $advertisement->sidebar_top_status == true && $advertisement->sidebar_top != null ) || ( $advertisement->sidebar_middle_status == true && $advertisement->sidebar_middle != null ) || ( $advertisement->sidebar_bottom_status == true && $advertisement->sidebar_bottom != null ) ) || $sidebar->tool_status == true || $sidebar->post_status == true ) ? 'col-lg-9' : 'col' }}">
                        @if ( $page->ads_status == true && $advertisement->area3_status == true && $advertisement->area3 != null )
                          <x-frontend.advertisement.area3 :advertisement="$advertisement" />
                        @endif

                        @if ( $page->type == 'home' )

                          @if ( $general->search_box_status == true )
                            <section id="search-box" class="mb-3">
                              <div class="input-icon">
                                  <span class="input-icon-addon">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <circle cx="10" cy="10" r="7"></circle>
                                            <line x1="21" y1="21" x2="15" y2="15"></line>
                                        </svg>
                                  </span>
                                  <input type="text" class="form-control search-input" wire:model="searchQuery" placeholder="{{ __('Search for your tool') }}" />
                              </div>

                              @if ( !empty($search_queries) && !empty($searchQuery) )
                                <div class="card mb-3 overflow-auto" style="max-height: 18rem">
                                  <div class="card-body pb-0">
                                    <div class="row">
                                        @foreach ($search_queries as $key => $value)
                                          <div class="col-12 col-md-6 col-lg-4 mb-3">
                                              <a class="card text-decoration-none cursor-pointer item-box" href="{{ (empty($value['custom_tool_link'])) ? route('home') . '/' . $value['slug'] : $value['custom_tool_link'] }}" {{ (empty($value['custom_tool_link'])) ? "" : 'target=_blank' }}>
                                                  <div class="card-body">
                                                      <div class="d-flex align-items-center">
                                                          <span class="avatar me-3 bg-transparent {{ ($general->lazy_loading == true) ? 'lazyload' : '' }}" data-bg="{{ ($value['icon_image']) ? $value['icon_image'] : asset('assets/img/no-thumb.svg') }}" @if ($general->lazy_loading == false) style="background-image:url({{ ($value['icon_image']) ? $value['icon_image'] : asset('assets/img/no-thumb.svg') }});" @endif></span>
                                                          <div>
                                                              <div class="font-weight-medium">{{ $value['title'] }}</div>
                                                          </div>
                                                      </div>
                                                  </div>
                                              </a>
                                          </div>
                                        @endforeach
                                    </div>
                                  </div>
                                </div>
                              @endif

                            </section>
                          @endif

                          <section id="tools-box">
                                @if ( !empty($tool_with_categories) )

                                      @foreach ($tool_with_categories as $key => $value)
                                       <div class="card mb-3">
                                          <div class="d-block card-header category-box text-{{ $value['align'] }} {{ ($value['background'] == 'bg-white') ? $value['background'] : $value['background'] . ' text-white'}}">
                                            <h3 class="card-title">{{ __($value['title']) }}</h3>
                                            <span>{{ __($value['description']) }}</span>
                                          </div>
                                          <div class="card-body pb-0">
                                                <div class="row">
                                                    @foreach ($value['pages'] as $key2 => $value2)
                                                      <div class="col-12 col-md-6 col-lg-4 mb-3">
                                                          <a class="card text-decoration-none cursor-pointer item-box" href="{{ (empty($value2['custom_tool_link'])) ? route('home') . '/' . $value2['slug'] : $value2['custom_tool_link'] }}" {{ (empty($value2['custom_tool_link'])) ? "" : 'target=_blank' }}>
                                                              <div class="card-body">
                                                                  <div class="d-flex align-items-center">
                                                                      <span class="avatar me-3 bg-transparent {{ ($general->lazy_loading == true) ? 'lazyload' : '' }}" data-bg="{{ ($value2['icon_image']) ? $value2['icon_image'] : asset('assets/img/no-thumb.svg') }}" @if ($general->lazy_loading == false) style="background-image:url({{ ($value2['icon_image']) ? $value2['icon_image'] : asset('assets/img/no-thumb.svg') }});" @endif></span>
                                                                      <div>
                                                                          <div class="font-weight-medium">{{ $value2['title'] }}</div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                          </a>
                                                      </div>
                                                    @endforeach
                                                </div>
                                          </div>
                                        </div>
                                      @endforeach

                                @else

                                    <div class="row">
                                      @foreach ($tools as $key => $value)
                                        <div class="col-12 col-md-6 col-lg-4 mb-3">
                                            <a class="card text-decoration-none cursor-pointer item-box" href="{{ ( empty( $value['custom_tool_link'] ) ) ? route('home') . '/' . $value['slug'] : $value['custom_tool_link'] }}" {{ (empty($value['custom_tool_link'])) ? "" : 'target=_blank' }}>
                                                <div class="card-body">
                                                    <div class="d-flex align-items-center">
                                                        <span class="avatar me-3 bg-transparent {{ ($general->lazy_loading == true) ? 'lazyload' : '' }}" data-bg="{{ ($value['icon_image']) ? $value['icon_image'] : asset('assets/img/no-thumb.svg') }}" @if ($general->lazy_loading == false) style="background-image:url({{ ($value['icon_image']) ? $value['icon_image'] : asset('assets/img/no-thumb.svg') }});" @endif></span>
                                                        <div>
                                                            <div class="font-weight-medium">{{ $value['title'] }}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                      @endforeach
                                    </div>
                                @endif
                          </section>

                        @endif

                            <section id="content-box" class="mb-3 page-{{ $page->id }}">

                                @if ( $page->type == 'tool')
                                  <div class="card mb-3">
                                    <div class="card-body">

                                      @switch($page->tool_name)

                                          @case('XML to JSON')
                                                @livewire('frontend.tools.xml-to-json')
                                              @break
                                              
                                          @case('CSV to JSON')
                                                @livewire('frontend.tools.csv-to-json')
                                              @break

                                          @case('TSV to JSON')
                                                @livewire('frontend.tools.tsv-to-json')
                                              @break

                                          @case('JSON to XML')
                                                @livewire('frontend.tools.json-to-xml')
                                              @break

                                          @case('JSON to CSV')
                                                @livewire('frontend.tools.json-to-csv')
                                              @break

                                          @case('JSON to Text')
                                                @livewire('frontend.tools.json-to-text')
                                              @break

                                          @case('JSON to TSV')
                                                @livewire('frontend.tools.json-to-tsv')
                                              @break

                                          @case('JSON Minify')
                                                @livewire('frontend.tools.json-minify')
                                              @break

                                          @case('JSON Editor')
                                                @livewire('frontend.tools.json-editor')
                                              @break

                                          @case('JSON Validator')
                                                @livewire('frontend.tools.json-validator')
                                              @break

                                          @case('JSON Formatter')
                                                @livewire('frontend.tools.json-formatter')
                                              @break

                                          @case('JSON Viewer')
                                                @livewire('frontend.tools.json-viewer')
                                              @break

                                          @case('Roman Numerals to Number')
                                                @livewire('frontend.tools.roman-numerals-to-number')
                                              @break

                                          @case('Number to Roman Numerals')
                                                @livewire('frontend.tools.number-to-roman-numerals')
                                              @break
                                              
                                          @case('Charge Converter')
                                                @livewire('frontend.tools.charge-converter')
                                              @break

                                          @case('Torque Converter')
                                                @livewire('frontend.tools.torque-converter')
                                              @break

                                          @case('Word to Number Converter')
                                                @livewire('frontend.tools.word-to-number-converter')
                                              @break

                                          @case('Number to Word Converter')
                                                @livewire('frontend.tools.number-to-word-converter')
                                              @break

                                          @case('Currency Converter')
                                                @livewire('frontend.tools.currency-converter')
                                              @break

                                          @case('Angle Converter')
                                                @livewire('frontend.tools.angle-converter')
                                              @break

                                          @case('Frequency Converter')
                                                @livewire('frontend.tools.frequency-converter')
                                              @break

                                          @case('Illuminance Converter')
                                                @livewire('frontend.tools.illuminance-converter')
                                              @break

                                          @case('Volumetric Flow Rate Converter')
                                                @livewire('frontend.tools.volumetric-flow-rate-converter')
                                              @break

                                          @case('Reactive Energy Converter')
                                                @livewire('frontend.tools.reactive-energy-converter')
                                              @break

                                          @case('Energy Converter')
                                                @livewire('frontend.tools.energy-converter')
                                              @break

                                          @case('Apparent Power Converter')
                                                @livewire('frontend.tools.apparent-power-converter')
                                              @break

                                          @case('Reactive Power Converter')
                                                @livewire('frontend.tools.reactive-power-converter')
                                              @break

                                          @case('Power Converter')
                                                @livewire('frontend.tools.power-converter')
                                              @break

                                          @case('Voltage Converter')
                                                @livewire('frontend.tools.voltage-converter')
                                              @break

                                          @case('Current Converter')
                                                @livewire('frontend.tools.current-converter')
                                              @break

                                          @case('Pressure Converter')
                                                @livewire('frontend.tools.pressure-converter')
                                              @break

                                          @case('Pace Converter')
                                                @livewire('frontend.tools.pace-converter')
                                              @break

                                          @case('Speed Converter')
                                                @livewire('frontend.tools.speed-converter')
                                              @break

                                          @case('Parts Per Converter')
                                                @livewire('frontend.tools.parts-per-converter')
                                              @break

                                          @case('Digital Converter')
                                                @livewire('frontend.tools.digital-converter')
                                              @break

                                          @case('Time Converter')
                                                @livewire('frontend.tools.time-converter')
                                              @break

                                          @case('Each Converter')
                                                @livewire('frontend.tools.each-converter')
                                              @break

                                          @case('Temperature Converter')
                                                @livewire('frontend.tools.temperature-converter')
                                              @break

                                          @case('Volume Converter')
                                                @livewire('frontend.tools.volume-converter')
                                              @break

                                          @case('Weight Converter')
                                                @livewire('frontend.tools.weight-converter')
                                              @break

                                          @case('Area Converter')
                                                @livewire('frontend.tools.area-converter')
                                              @break

                                          @case('Length Converter')
                                                @livewire('frontend.tools.length-converter')
                                              @break

                                          @case('GST Calculator')
                                                @livewire('frontend.tools.gst-calculator')
                                              @break

                                          @case('Loan Calculator')
                                                @livewire('frontend.tools.loan-calculator')
                                              @break

                                          @case('CPM Calculator')
                                                @livewire('frontend.tools.cpm-calculator')
                                              @break
                                              
                                          @case('Discount Calculator')
                                                @livewire('frontend.tools.discount-calculator')
                                              @break

                                          @case('Paypal Fee Calculator')
                                                @livewire('frontend.tools.paypal-fee-calculator')
                                              @break

                                          @case('Probability Calculator')
                                                @livewire('frontend.tools.probability-calculator')
                                              @break

                                          @case('Margin Calculator')
                                                @livewire('frontend.tools.margin-calculator')
                                              @break

                                          @case('Sales Tax Calculator')
                                                @livewire('frontend.tools.sales-tax-calculator')
                                              @break
                                              
                                          @case('Confidence Interval Calculator')
                                                @livewire('frontend.tools.confidence-interval-calculator')
                                              @break
                                              
                                          @case('Average Calculator')
                                                @livewire('frontend.tools.average-calculator')
                                              @break

                                          @case('Percentage Calculator')
                                                @livewire('frontend.tools.percentage-calculator')
                                              @break

                                          @case('Age Calculator')
                                                @livewire('frontend.tools.age-calculator')
                                              @break

                                          @case('Decimal to Text')
                                                @livewire('frontend.tools.decimal-to-text')
                                              @break

                                          @case('Text to Decimal')
                                                @livewire('frontend.tools.text-to-decimal')
                                              @break

                                          @case('HEX to Text')
                                                @livewire('frontend.tools.hex-to-text')
                                              @break

                                          @case('Text to HEX')
                                                @livewire('frontend.tools.text-to-hex')
                                              @break

                                          @case('Octal to Text')
                                                @livewire('frontend.tools.octal-to-text')
                                              @break

                                          @case('Text to Octal')
                                                @livewire('frontend.tools.text-to-octal')
                                              @break

                                          @case('Octal to HEX')
                                                @livewire('frontend.tools.octal-to-hex')
                                              @break

                                          @case('HEX to Octal')
                                                @livewire('frontend.tools.hex-to-octal')
                                              @break

                                          @case('Decimal to Octal')
                                                @livewire('frontend.tools.decimal-to-octal')
                                              @break

                                          @case('Octal to Decimal')
                                                @livewire('frontend.tools.octal-to-decimal')
                                              @break

                                          @case('Binary to Octal')
                                                @livewire('frontend.tools.binary-to-octal')
                                              @break

                                          @case('Octal to Binary')
                                                @livewire('frontend.tools.octal-to-binary')
                                              @break

                                          @case('Decimal to HEX')
                                                @livewire('frontend.tools.decimal-to-hex')
                                              @break

                                          @case('HEX to Decimal')
                                                @livewire('frontend.tools.hex-to-decimal')
                                              @break

                                          @case('Text to ASCII')
                                                @livewire('frontend.tools.text-to-ascii')
                                              @break

                                          @case('ASCII to Text')
                                                @livewire('frontend.tools.ascii-to-text')
                                              @break

                                          @case('Binary to Decimal')
                                                @livewire('frontend.tools.binary-to-decimal')
                                              @break

                                          @case('Decimal to Binary')
                                                @livewire('frontend.tools.decimal-to-binary')
                                              @break
                                              
                                          @case('Binary to ASCII')
                                                @livewire('frontend.tools.binary-to-ascii')
                                              @break

                                          @case('ASCII to Binary')
                                                @livewire('frontend.tools.ascii-to-binary')
                                              @break
                                              
                                          @case('Binary to HEX')
                                                @livewire('frontend.tools.binary-to-hex')
                                              @break

                                          @case('HEX to Binary')
                                                @livewire('frontend.tools.hex-to-binary')
                                              @break

                                          @case('Word to HTML')
                                                @livewire('frontend.tools.word-to-html')
                                              @break

                                          @case('Word to ODT')
                                                @livewire('frontend.tools.word-to-odt')
                                              @break

                                          @case('ODT to PDF')
                                                @livewire('frontend.tools.odt-to-pdf')
                                              @break

                                          @case('RTF to PDF')
                                                @livewire('frontend.tools.rtf-to-pdf')
                                              @break

                                          @case('Text to PDF')
                                                @livewire('frontend.tools.text-to-pdf')
                                              @break

                                          @case('JPG to PDF')
                                                @livewire('frontend.tools.jpg-to-pdf')
                                              @break

                                          @case('PNG to PDF')
                                                @livewire('frontend.tools.png-to-pdf')
                                              @break

                                          @case('HTML to PDF')
                                                @livewire('frontend.tools.html-to-pdf')
                                              @break

                                          @case('Excel to PDF')
                                                @livewire('frontend.tools.excel-to-pdf')
                                              @break

                                          @case('Word to PDF')
                                                @livewire('frontend.tools.word-to-pdf')
                                              @break

                                          @case('PowerPoint to PDF')
                                                @livewire('frontend.tools.powerpoint-to-pdf')
                                              @break
                                              
                                          @case('Random Word Generator')
                                                @livewire('frontend.tools.random-word-generator')
                                              @break

                                          @case('Image To Text')
                                                @livewire('frontend.tools.image-to-text')
                                              @break
                                              
                                          @case('WebP to JPG')
                                                @livewire('frontend.tools.webp-to-jpg')
                                              @break

                                          @case('JPG Converter')
                                                @livewire('frontend.tools.jpg-converter')
                                              @break

                                          @case('PNG to JPG')
                                                @livewire('frontend.tools.png-to-jpg')
                                              @break

                                          @case('JPG to PNG')
                                                @livewire('frontend.tools.jpg-to-png')
                                              @break

                                          @case('RGB to HEX')
                                                @livewire('frontend.tools.rgb-to-hex')
                                              @break

                                          @case('HEX to RGB')
                                                @livewire('frontend.tools.hex-to-rgb')
                                              @break

                                          @case('Random Word Generator')
                                                @livewire('frontend.tools.random-word-generator')
                                              @break

                                          @case('Online Text Editor')
                                                @livewire('frontend.tools.online-text-editor')
                                              @break

                                          @case('Binary to Text')
                                                @livewire('frontend.tools.binary-to-text')
                                              @break

                                          @case('Text to Binary')
                                                @livewire('frontend.tools.text-to-binary')
                                              @break

                                          @case('SRT to VTT')
                                                @livewire('frontend.tools.srt-to-vtt')
                                              @break

                                          @case('VTT to SRT')
                                                @livewire('frontend.tools.vtt-to-srt')
                                              @break

                                          @case('YouTube Thumbnail Downloader')
                                                @livewire('frontend.tools.youtube-thumbnail-downloader')
                                              @break

                                          @case('Image Resizer')
                                                @livewire('frontend.tools.image-resizer')
                                              @break

                                          @case('Image Converter')
                                                @livewire('frontend.tools.image-converter')
                                              @break

                                          @case('Image Compressor')
                                                @livewire('frontend.tools.image-compressor')
                                              @break

                                          @case('Image Enlarger')
                                                @livewire('frontend.tools.image-enlarger')
                                              @break

                                          @case('Image Cropper')
                                                @livewire('frontend.tools.image-cropper')
                                              @break

                                          @case('Rotate Image')
                                                @livewire('frontend.tools.rotate-image')
                                              @break

                                          @case('Flip Image')
                                                @livewire('frontend.tools.flip-image')
                                              @break

                                          @case('Base64 to Image')
                                                @livewire('frontend.tools.base64-to-image')
                                              @break

                                          @case('Image to Base64')
                                                @livewire('frontend.tools.image-to-base64')
                                              @break

                                          @case('Find Facebook ID')
                                                @livewire('frontend.tools.find-facebook-id')
                                              @break

                                          @case('Remove Line Breaks')
                                                @livewire('frontend.tools.remove-line-breaks')
                                              @break

                                          @case('Word Counter')
                                                @livewire('frontend.tools.word-counter')
                                              @break

                                          @case('Password Generator')
                                                @livewire('frontend.tools.password-generator')
                                              @break

                                          @case('Color Converter')
                                                @livewire('frontend.tools.color-converter')
                                              @break

                                          @case('ICO Converter')
                                                @livewire('frontend.tools.ico-converter')
                                              @break

                                          @case('ICO to PNG')
                                                @livewire('frontend.tools.ico-to-png')
                                              @break

                                          @case('Case Converter')
                                                @livewire('frontend.tools.case-converter')
                                              @break

                                          @case('Lorem Ipsum Generator')
                                                @livewire('frontend.tools.lorem-ipsum-generator')
                                              @break

                                          @case('QR Code Generator')
                                                @livewire('frontend.tools.qr-code-generator')
                                              @break

                                          @case('QR Code Decoder')
                                                @livewire('frontend.tools.qr-code-decoder')
                                              @break

                                          @case('Javascript Obfuscator')
                                                @livewire('frontend.tools.javascript-obfuscator')
                                              @break

                                          @case('Javascript DeObfuscator')
                                                @livewire('frontend.tools.javascript-de-obfuscator')
                                              @break

                                          @case('Base64 Encode')
                                                @livewire('frontend.tools.base64-encode')
                                              @break

                                          @case('Base64 Decode')
                                                @livewire('frontend.tools.base64-decode')
                                              @break

                                          @case('HTML Encode')
                                                @livewire('frontend.tools.html-encode')
                                              @break

                                          @case('HTML Decode')
                                                @livewire('frontend.tools.html-decode')
                                              @break

                                          @case('URL Encode')
                                                @livewire('frontend.tools.url-encode')
                                              @break

                                          @case('URL Decode')
                                                @livewire('frontend.tools.url-decode')
                                              @break

                                          @case('HTML Minifier')
                                                @livewire('frontend.tools.html-minifier')
                                              @break

                                          @case('HTML Beautifier')
                                                @livewire('frontend.tools.html-beautifier')
                                              @break

                                          @case('CSS Minifier')
                                                @livewire('frontend.tools.css-minifier')
                                              @break

                                          @case('CSS Beautifier')
                                                @livewire('frontend.tools.css-beautifier')
                                              @break

                                          @case('JavaScript Minifier')
                                                @livewire('frontend.tools.javascript-minifier')
                                              @break

                                          @case('JavaScript Beautifier')
                                                @livewire('frontend.tools.javascript-beautifier')
                                              @break

                                          @case('Text to Slug')
                                                @livewire('frontend.tools.text-to-slug')
                                              @break

                                          @case('MD5 Generator')
                                                @livewire('frontend.tools.md5-generator')
                                              @break

                                          @case('What Is My IP')
                                                @livewire('frontend.tools.what-is-my-ip')
                                              @break

                                          @case('IP Address Lookup')
                                                @livewire('frontend.tools.ip-address-lookup')
                                              @break
                                              
                                          @default
                                      @endswitch
                                      
                                    </div>
                                  </div>
                                @endif
                        
                                @if ( !empty($related_tools) && $general->related_tools == true && $page->type == 'tool' )
                                    <section>
                                        <div class="card mb-3">
                                            <div class="d-block card-header related-tools-box text-start {{ ($general->related_tools_background == 'bg-white') ? $general->related_tools_background : $general->related_tools_background . ' text-white'}}">
                                              <h3 class="card-title">{{ __('Related Tools') }}</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">
                                                  @foreach ($related_tools as $key => $value)
                                                    <div class="col-12 col-md-6 col-lg-4 mb-3">
                                                        <a class="card text-decoration-none cursor-pointer item-box" href="{{ ( empty( $value['custom_tool_link'] ) ) ? route('home') . '/' . $value['slug'] : $value['custom_tool_link'] }}" {{ (empty($value['custom_tool_link'])) ? "" : 'target=_blank' }}>
                                                            <div class="card-body">
                                                                <div class="d-flex align-items-center">
                                                                    <span class="avatar me-3 bg-transparent {{ ($general->lazy_loading == true) ? 'lazyload' : '' }}" data-bg="{{ ($value['icon_image']) ? $value['icon_image'] : asset('assets/img/no-thumb.svg') }}" @if ($general->lazy_loading == false) style="background-image:url({{ ($value['icon_image']) ? $value['icon_image'] : asset('assets/img/no-thumb.svg') }});" @endif></span>
                                                                    <div>
                                                                        <div class="font-weight-medium">{{ $value['title'] }}</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                  @endforeach
                                              </div>
                                            </div>
                                        </div>
                                    </section>
                                @endif

                                <div class="card">
                                    @if ( $general->parallax_status == false )
                                        <div class="card-header d-block">
                                              <h1 class="page-title">{{ __($pageTrans->title) }}</h1>
                                              <p class="mb-0">{{ __($pageTrans->subtitle) }}</p>
                                        </div>
                                    @endif

                                    <div class="card-body {{ ($general->author_box_status == true) ? 'pb-0' : ''}}">
                                        @if ( Auth::user() && Auth::user()->is_admin == 1 )
                                          <div class="d-flex justify-content-center mb-3">
                                            <a href="{{ localization()->getLocalizedURL($pageTrans->locale, route('edit-page-translations', $pageTrans->translations[0]['id']), [], true) }}" class="btn btn-primary">{{ __('Edit Page') }}</a>
                                          </div>
                                        @endif

                                        @if ( $page->ads_status == true && $advertisement->area4_status == true && $advertisement->area4 != null )
                                          <x-frontend.advertisement.area4 :advertisement="$advertisement" />
                                        @endif

                                        {!! $pageTrans->description !!}

                                        @if ( $page->ads_status == true && $advertisement->area5_status == true && $advertisement->area5 != null )
                                          <x-frontend.advertisement.area5 :advertisement="$advertisement" />
                                        @endif

                                        @switch( $page->type )

                                            @case('report')
                                                  @livewire('frontend.report')
                                                @break

                                            @case('contact')
                                                  @livewire('frontend.contact')
                                                @break

                                            @default
                                        @endswitch

                                      @if ( $general->share_icons_status == true )
                                        <div class="social-share text-center">
                                          <div class="is-divider"></div>
                                          <div class="share-icons relative">

                                              <a wire:ignore href="https://www.facebook.com/sharer.php?u={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}"
                                                  onclick="window.open('https://www.facebook.com/sharer/sharer.php?u={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}','facebook','height=500,width=800,resizable=1,scrollbars=yes'); return false;"
                                                  data-label="Facebook"
                                                  rel="noopener noreferrer nofollow"
                                                  target="_blank"
                                                  class="btn btn-facebook btn-simple rounded p-2">
                                                  <i class="fab fa-facebook"></i>
                                              </a>

                                              <a wire:ignore href="https://twitter.com/share?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}"
                                                  onclick="window.open('https://twitter.com/share?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}','twitter','height=500,width=800,resizable=1,scrollbars=yes'); return false;"
                                                  rel="noopener noreferrer nofollow"
                                                  target="_blank"
                                                  class="btn btn-twitter btn-simple rounded p-2">
                                                  <i class="fab fa-twitter"></i>
                                              </a>

                                              <a wire:ignore href="https://www.pinterest.com/pin-builder/?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}&media={{ $page->featured_image }}&description={{ str_replace(' ', '%20', $pageTrans->title) }}"
                                                  onclick="window.open('https://www.pinterest.com/pin-builder/?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}&media={{ $page->featured_image }}&description={{ str_replace(' ', '%20', $pageTrans->title) }}','pinterest','height=500,width=800,resizable=1,scrollbars=yes'); return false;"
                                                  rel="noopener noreferrer nofollow"
                                                  target="_blank"
                                                  class="btn btn-pinterest btn-simple rounded p-2">
                                                  <i class="fab fa-pinterest"></i>
                                              </a>

                                              <a wire:ignore href="https://www.linkedin.com/sharing/share-offsite/?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}"
                                                  onclick="window.open('https://www.linkedin.com/sharing/share-offsite/?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}','linkedin','height=500,width=800,resizable=1,scrollbars=yes'); return false;"
                                                  rel="noopener noreferrer nofollow"
                                                  target="_blank"
                                                  class="btn btn-linkedin btn-simple rounded p-2">
                                                  <i class="fab fa-linkedin"></i>
                                              </a>

                                              <a wire:ignore href="https://www.reddit.com/submit?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}&title={{ str_replace(' ', '%20', $pageTrans->title) }}"
                                                  onclick="window.open('https://www.reddit.com/submit?url={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}&title={{ str_replace(' ', '%20', $pageTrans->title) }}','reddit','height=500,width=800,resizable=1,scrollbars=yes'); return false;"
                                                  rel="noopener noreferrer nofollow"
                                                  target="_blank"
                                                  class="btn btn-reddit btn-simple rounded p-2">
                                                  <i class="fab fa-reddit"></i>
                                              </a>

                                              <a wire:ignore href="https://tumblr.com/widgets/share/tool?canonicalUrl={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}"
                                                  onclick="window.open('https://tumblr.com/widgets/share/tool?canonicalUrl={{ ($page->type == 'home') ? route('home') : route('page', $page->slug ) }}','tumblr','height=500,width=800,resizable=1,scrollbars=yes'); return false;"
                                                  target="_blank"
                                                  class="btn btn-tumblr btn-simple rounded p-2"
                                                  rel="noopener noreferrer nofollow">
                                                  <i class="fab fa-tumblr"></i>
                                              </a>

                                          </div>
                                        </div>
                                      @endif

                                      @if ( $general->author_box_status == true )

                                        <hr class="horizontal dark">
                                        <div class="my-3">
                                          <div class="row">

                                            <div class="col-lg-2">
                                                <div class="position-relative mb-3">
                                                  <div class="blur-shadow-image">
                                                    <img class="w-100 rounded-3 shadow-sm {{ ($general->lazy_loading == true) ? 'lazyload' : '' }}" {{ ($general->lazy_loading == true) ? 'data-' : '' }}src="{{ $profile->avatar }}">
                                                  </div>
                                                </div>
                                            </div>

                                            <div class="col-lg-10 ps-0">
                                              <div class="card-body text-start py-0">

                                                <div class="p-md-0 pt-3">
                                                  <h5 class="font-weight-bolder mb-0">{{ $profile->fullname }}</h5>
                                                  <p class="text-uppercase text-sm font-weight-bold mb-2">{{ $profile->position }}</p>
                                                </div>

                                                <p class="mb-3">{{ __($profile->bio) }}</p>

                                                @if ( ($profile->social_status == true) && !empty($profile->user_socials) )

                                                  @foreach ($profile->user_socials as $element)

                                                    <a class="btn btn-{{ $element->name }} btn-simple mb-0 ps-1 pe-2 py-0" href="{{ $element->url }}" target="blank">
                                                      <i class="fab fa-{{ $element->name }} fa-lg" aria-hidden="true"></i>
                                                    </a>

                                                  @endforeach

                                                @endif

                                              </div>
                                            </div>

                                          </div>
                                        </div>

                                      @endif

                                    </div>
                                </div>
                            </section>
                    </div>

                    @if ( $page->ads_status == true && ( ( $advertisement->sidebar_top_status == true && $advertisement->sidebar_top != null ) || ( $advertisement->sidebar_middle_status == true && $advertisement->sidebar_middle != null ) || ( $advertisement->sidebar_bottom_status == true && $advertisement->sidebar_bottom != null ) ) || $sidebar->tool_status == true || $sidebar->post_status == true)
                      <div class="col-lg-3 ml-auto">
                          <x-frontend.sidebar :page="$page" :general="$general" :advertisement="$advertisement" :sidebar="$sidebar" :recentPosts="$recent_posts" :popularTools="$popular_tools" />
                      </div>
                    @endif

                </div>
            </div>

        </section>
    </main>

    <x-frontend.footer :footer="$footer" :general="$general" :socials="$socials" />

    <!-- Theme JS -->
    <script src="{{ asset('assets/js/main.min.js') }}"></script>

    @if ( $general->lazy_loading == true )
      <script src="{{ asset('assets/js/lazysizes.min.js') }}" async></script>
      <script src="{{ asset('assets/js/ls.unveilhooks.min.js') }}" async></script>
    @endif

    @if ( $captcha->status == true && !empty($captcha->site_key ) && !empty($captcha->secret_key ) )
      <script src="https://www.google.com/recaptcha/api.js?render={{ $captcha->site_key }}"></script>
    @endif

    @if ( $general->back_to_top == true )
        <!-- Scroll back to top -->
        <div id="backtotop"> 
            <a href="javascript:void(0)" class="backtotop"></a> 
        </div>

        <script type="text/javascript"> 
            jQuery(document).ready(function ($) {
                $("#backtotop").hide(); 
                $(window).scroll(function () { 
                    if ($(this).scrollTop() > 500) { 
                        $('#backtotop').fadeIn(); 
                    } else { 
                        $('#backtotop').fadeOut(); 
                    } 
                });   
            });

            jQuery('.backtotop').click(function () { 
                jQuery('html, body').animate({ 
                    scrollTop: 0 
                }, 'slow'); 
            });
        </script> 
        <!-- End of Scroll back to top -->
    @endif
    
    @if ( $general->back_to_top == true )
        <!-- Scroll back to top -->
        <div id="backtotop"> 
            <a href="javascript:void(0)" class="backtotop"></a> 
        </div>

        <script type="text/javascript"> 
            jQuery(document).ready(function ($) {
                $("#backtotop").hide(); 
                $(window).scroll(function () { 
                    if ($(this).scrollTop() > 500) { 
                        $('#backtotop').fadeIn(); 
                    } else { 
                        $('#backtotop').fadeOut(); 
                    } 
                });   
            });

            jQuery('.backtotop').click(function () { 
                jQuery('html, body').animate({ 
                    scrollTop: 0 
                }, 'slow'); 
            });
        </script> 
        <!-- End of Scroll back to top -->
    @endif

    @if ( $general->adblock_detection == true )

      <!-- Sweetalert2 -->
      <script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>

      <script src="{{ asset('assets/js/prebid-ads.js') }}"></script>

      <script>
      (function( $ ) {
        "use strict";

              if( window.canRunAds === undefined ){
                  Swal.fire({
                    title: "{{ __('You\'re blocking ads') }}",
                    text: "{{ __('Our website is made possible by displaying online ads to our visitors. Please consider supporting us by disabling your ad blocker.') }}",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: "{{ __('I have disabled Adblock') }}",
                    cancelButtonText: "{{ __('No, thanks!') }}"
                  }).then((result) => {
                    if (result.isConfirmed) {
                      window.location.reload();
                    }
                  });
              }

      })( jQuery );
      </script>

    @endif

    @if (Cookie::get('cookies') == null)

      @if ( $notice->status == true )

            <div class="cookies-wrapper position-fixed {{ $notice->align }}">
                <div class="{{ $notice->background }} {{ ($notice->background != 'bg-white') ? 'text-white' : 'text-dark' }} py-3 px-2 rounded shadow">
                    <div class="card-body">
                        <div class="mb-3">
                            <img src="{{ asset('assets/img/cookie.svg') }}" alt="{{ __('Cookie') }}">
                        </div>

                        <div>
                            <span class="text-start">{!! __(GrahamCampbell\Security\Facades\Security::clean($notice->notice)) !!}</span>
                        </div>
                    </div>

                        @if ( $notice->button == true)
                            <div class="text-center">
                                <button id="acceptCookies" class="btn bg-success mb-0 text-capitalize text-white"> {{ __('Accept all cookies') }} </button>
                            </div>
                         @endif
                    </div>

                </div>
            </div>

          <script>
             (function( $ ) {
                "use strict";

                    jQuery("#acceptCookies").click(function(){
                        jQuery.ajax({
                            type : 'get',
                            url : '{{ url('/') }}/cookies/accept',
                            success: function(e) {
                                jQuery('.cookies-wrapper').remove();
                            }
                        });
                    });

            })( jQuery );
          </script>
      @endif

    @endif

    @if ( $general->dir_mode == true )
        <script>
           (function( $ ) {
              "use strict";

                  jQuery(".btn-toggle-dir").click(function(){
                      jQuery.ajax({
                          type : 'get',
                          url : '{{ url('/') }}/dir/mode',
                          success: function(e) {
                              window.location.reload();
                          }
                      });
                  });

          })( jQuery );
        </script>
      @endif

    @if ( $general->theme_mode == true )
      <script>
         (function( $ ) {
            "use strict";

                jQuery(".btn-toggle-mode").click(function(){
                    jQuery.ajax({
                        type : 'get',
                        url : '{{ url('/') }}/theme/mode',
                        success: function(e) {
                            window.location.reload();
                        }
                    });
                });

        })( jQuery );
      </script>
    @endif

    <script>
        function copyToClipboard() {
          document.getElementById("text").select();
          document.execCommand('copy');
        }
    </script>
    
    @if ( $advanced->footer_status == true && $advanced->insert_footer != null )
      {!! $advanced->insert_footer !!}
    @endif

  </div>